package com.petapp.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetappBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetappBackendApplication.class, args);
	}

}
