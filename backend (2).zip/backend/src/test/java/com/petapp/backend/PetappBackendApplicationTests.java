package com.petapp.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetappBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
